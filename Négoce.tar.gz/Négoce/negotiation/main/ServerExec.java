package negotiation.main;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.rmi.Naming;

import negotiation.server.controller.NegotiationController;
import negotiation.server.model.Auction;


public class ServerExec implements RMIData{	
	
	public static ServerGUI serverGUI;
	
	public static String [] participantsNames = new String [] {"Joe","William","Jack","Avrell"};
	
	public static void main(String argv []){
		
		Auction auction=new Auction(participantsNames);			
		
		BufferedReader bufferedReader;
		FileReader fileReader;
		String serverIp = null;
		int port = -1;
		
		try {
			// reading port and ip server to use
			fileReader=new FileReader(IpServerFile);
			bufferedReader = new BufferedReader(fileReader);
			serverIp = bufferedReader.readLine();			
			port = Integer.parseInt(bufferedReader.readLine());
			
			// controller creation
			NegotiationController negotiationController=new NegotiationController(auction);
			
			// controller registration
			java.rmi.registry.LocateRegistry.createRegistry(port);
			Naming.rebind("rmi://"+serverIp+"/"+name, negotiationController);			
			
			bufferedReader.close();
			fileReader.close();
			
		} catch (FileNotFoundException e1) {
			System.err.println("Fichier introuvable");
			e1.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}	
		serverGUI=new ServerGUI();		
	} 	
}	// end class ServeurExec


