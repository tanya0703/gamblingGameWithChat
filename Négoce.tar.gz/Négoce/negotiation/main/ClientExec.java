package negotiation.main;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.rmi.Naming;
import java.rmi.NotBoundException;

import negotiation.client.view.View2D;
import negotiation.server.controller.NegotiationControllerIf;


public class ClientExec implements RMIData{
	
	public static void main(String argv []){	
		
		BufferedReader bufferedReader = null;
		FileReader fileReader = null;
		String serverIp, port;
		
		try {
			// reading port and ip server to use
			fileReader=new FileReader(IpServerFile);
			bufferedReader = new BufferedReader(fileReader);
			serverIp = bufferedReader.readLine();			
			port = bufferedReader.readLine();
			
			// controller retrieval
			NegotiationControllerIf controller=(NegotiationControllerIf)Naming.lookup("rmi://"+serverIp+":"+port+"/"+name);			
			
			// view creation
			View2D theView=new View2D();
			
			controller.connect(theView);			
			
			bufferedReader.close();
			fileReader.close();
			
		} catch (FileNotFoundException e1) {
			System.err.println("Fichier introuvable");
			e1.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		catch (NotBoundException e) {
			e.printStackTrace();
		}
		
		
		/* pour tester la vue (� virer) TODO
		
		int [] othersNumbers=new int []{0,1,2};
		Auction auction=new Auction(participantsNames);
	
		NegotiationController controller;
		try {
			controller = new NegotiationController(auction);
			View2D theView=new View2D();
			theView.init(othersNumbers, 3, controller);
			
		} catch (RemoteException e) {
			e.printStackTrace();
		}	*/ 
		
	}// end main
}
