package negotiation.main;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JTextArea;

import negotiation.server.controller.LogManager;


public class ServerGUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private static JTextArea infos;

	public ServerGUI() {
		super("Server");
		init();
		this.setSize(100, 100);
		this.pack();		
		this.center();
		this.setVisible(true);
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				// TODO D�connecter les clients
				LogManager.println("Fin");
				LogManager.close();
				System.exit(0);
			}
		});
	}

	private void init() {
		Container c = getContentPane();
		infos = new JTextArea(20, 25);
		infos.setEditable(false);
		c.add(infos, BorderLayout.CENTER);
	}

	void center() {
		Dimension tailleEcran = Toolkit.getDefaultToolkit().getScreenSize();
		int largeurEcran = tailleEcran.width;
		int hauteurEcran = tailleEcran.height;
		this.setSize(400,400);

		int largeur = this.getSize().width;
		int hauteur = this.getSize().height;

		int xPos = (largeurEcran - largeur) / 2;
		int yPos = ((hauteurEcran - hauteur) / 2) - 10;
		this.setLocation(xPos, yPos);
	}
	
	public static void display(String message, int participant) {
		infos.setForeground(Color.black); // prendre la couleur du participant (pour l'instant le serveur �crit en noir)
		infos.append(message+"\n");
		System.out.println(message);
	}

}
