package negotiation.server.controller;

import java.io.IOException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Calendar;
import java.util.Vector;

import negotiation.data.AuctionData;
import negotiation.data.ColorData;
import negotiation.main.ServerGUI;
import negotiation.server.model.Auction;
import negotiation.server.model.Hand;
import negotiation.server.model.Participant;

//Controller in the meaning of MVC pattern

public class NegotiationController extends UnicastRemoteObject implements NegotiationControllerIf, ColorData, AuctionData {

	private Calendar calendar;

	private static final long serialVersionUID = 1L;

	private Vector<NegotiationView> views;

	private Auction auction;


	public NegotiationController(Auction auction) throws RemoteException,
			IOException {
		super();
		this.auction = auction;
		this.views = new Vector<NegotiationView>();
		LogManager.create();		
		LogManager.println("Lancement "+this.getHour());
		LogManager.println(auction);
	}

	public void auctionAcard(int seller, int cardType) throws RemoteException {

		// check if the seller is the current seller
		if (auction.getCurrentSellerNumber() == seller) {
			// check if the participant has the proposed card
			if (auction.getParticipant(seller).getHand().hasCard(cardType)) {
				auction.getParticipant(seller).setSellingCard(cardType);
				this.auction.auctionAcard(seller);
				this.refresh();
			} else {
				System.err.println(" vente propos�e incorrecte : le participant ne poss�de pas la carte");
			}
		}
	}

	public synchronized void bidUp(int participant, int cardType, int coinsNb)
			throws RemoteException {
		
		// check the bid validity
		if ((cardType <= 0) && (coinsNb <= 0)) {
			System.err.println(" ench�re incorrecte : ench�re vide");
		} else if ((cardType >= 0) && (!auction.getParticipant(participant).getHand().hasCard(cardType))) {
			System.err.println(" ench�re incorrecte : carte propos�e non poss�d�e");
		} else if (coinsNb > getCoinsNumber(participant)) {
			System.err.println(" ench�re incorrecte : nb de pi�ces propos�es > nb de pi�ces poss�d�es");
		} else {
			auction.getParticipant(participant).makeABid(coinsNb, cardType);
			this.refresh();
		}
	}

	public synchronized void takeOut(int participant) throws RemoteException {
		auction.takeOut(participant);
		this.refresh();
	}

	public void acceptBid(int seller, int buyer) throws RemoteException {
		if(auction.hasProposedBid(buyer)){
			auction.acceptBid(seller, buyer);
			this.refresh();
		}
	}
	
	public String getParticipantSituation(int i) throws RemoteException {
		return auction.getParticipantSituation(i);
	}

	public String getName(int participant) throws RemoteException {
		return ((Participant) auction.getParticipant(participant)).getName();
	}

	public int[] getCards(int participant) throws RemoteException {
		int[] cards = new int[9];
		Hand hand = ((Participant) auction.getParticipant(participant))
				.getHand();

		for (int i = 0; i < cards.length; i++) {
			cards[i] = hand.getNb(i);
		}
		return cards;
	}

	public int getCoinsNumber(int participant) throws RemoteException {
		return auction.getParticipant(participant).getCoinsNumber();
	}

	public int getState(int participant) throws RemoteException {
		return auction.getParticipant(participant).getState();
	}

	public synchronized void connect(NegotiationView view) throws RemoteException {
		int participantNumber = this.views.size();
		LogManager.println("participant " + participantNumber + " connect�");
		this.addView(view);
		waitAllParticipant();
	}

	public synchronized void sendMessage(String user, int participant, String message) throws RemoteException {

		String hour = getHour();

		ServerGUI.display(hour + " " + user + " " + message, participant);

		LogManager.println(hour + " " + user + " " + message,htmlColors[participant]);

		for (NegotiationView view : this.views) {
			view.receiveMessage(hour, user, message, participant);
		}
	}
	
//_________ private methods __________________________________________________________
	
	private void addView(NegotiationView nv) {
		this.views.add(nv);
	}
	
	private void waitAllParticipant() throws RemoteException {
		if (views.size() == 4) {
			for (int i = 0; i < 4; i++) {
				NegotiationView nv = views.get(i);
				nv.init(this.auction.getOthersParticipantsNumbers(i), i, this);
			}
		}
	}
	
	private void refresh() {
		for (int i = 0; i < this.views.size(); i++) {
			try {
				this.views.get(i).refresh();
			} catch (RemoteException e) {
				System.err.println("RemoteException attrapp�e dans refresh du controlleur");
				e.printStackTrace();
			}
		}
	}
	
	private String getHour() {
		calendar = Calendar.getInstance();
		int val;
		String hour = new String();
		val = calendar.get(Calendar.HOUR_OF_DAY);
		if (val < 10) {
			hour += "0";
		}
		hour += val + ":";
		// Minutes
		val = calendar.get(Calendar.MINUTE);
		if (val < 10) {
			hour += "0";
		}
		hour += val + ":";
		// Seconds
		val = calendar.get(Calendar.SECOND);
		if (val < 10) {
			hour += "0";
		}
		hour += val;
		return hour;
	}
}
