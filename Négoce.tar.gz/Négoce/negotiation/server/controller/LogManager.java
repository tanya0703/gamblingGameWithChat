package negotiation.server.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Calendar;
import java.util.GregorianCalendar;

/** Output file management */
public class LogManager {

	private final static String logDirectory = "./logs/";

	private static PrintStream writer;

	public static void create() throws IOException {
		checkLogDirectory();
		String log = logName();
		writer = new PrintStream(new FileOutputStream(logDirectory + "/" + log));
	}

	public static void print(Object o) {
		synchronized (writer) {
			if (writer != null) {
				writeObject(o);
				writer.flush();
			}
		}
	}

	public static void print(Object o, String color) {
		synchronized (writer) {
			if (writer != null) {
				writer.print("<font color=" + color + ">");
				writeObject(o);
				writer.print("</font>");
				writer.flush();
			}
		}
	}

	public static void println(Object o) {
		synchronized (writer) {
			if (writer != null) {
				writeObject(o + "<br/>");
				writer.flush();
			}
		}
	}

	public static void println(Object o, String color) {
		synchronized (writer) {
			if (writer != null) {
				writer.print("<font color=" + color + ">");
				writeObject(o);
				writer.print("</font>" + "<br/>");
				writer.flush();
			}
		}
	}

	public static void close() {
		writer.close();
		writer = null;
	}

	private static void checkLogDirectory() {
			File dir = new File(logDirectory);
			if (!dir.exists())
				dir.mkdir();
	}

	private static String logName() {
		Calendar c = new GregorianCalendar();
		int val;
		String name = new String();
		// Year
		name = "log-" + c.get(Calendar.YEAR) + "-";
		// Month
		val = (c.get(Calendar.MONTH) + 1);
		if (val < 10) {
			name += "0";
		}
		name += val + "-";
		// Day
		val = c.get(Calendar.DAY_OF_MONTH);
		if (val < 10) {
			name += "0";
		}
		name += val + "-";
		// Hour
		val = c.get(Calendar.HOUR_OF_DAY);
		if (val < 10) {
			name += "0";
		}
		name += val + "h";
		// Minutes
		val = c.get(Calendar.MINUTE);
		if (val < 10) {
			name += "0";
		}
		name += val + ".htm";
		return name;

	}

	private static void writeObject(Object o) {
		String buffer = o.toString();
		String tokens[];
		tokens = buffer.split("\n");
		for (String token : tokens) {
			writer.print(token + "<br/>");
		}
	}
}
