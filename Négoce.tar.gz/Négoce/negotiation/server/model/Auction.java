package negotiation.server.model;

import java.util.Random;

import negotiation.server.controller.LogManager;



public class Auction implements BidManager {	

	private Participant [] participants;	
	private Bid[] currentBids;
	private Participant currentSeller;
	private int currentBuyersNb;
	private boolean fini;
	private int winner; // winner index in the participants tab
	
	public Auction(String [] participantsNames){		
		this.currentBids=new Bid[participantsNames.length];
		
		this.currentBuyersNb=4;
		this.currentSeller = null;
		this.winner=-1;
		this.initBids();
		participants=new Participant[participantsNames.length];
		this.init(participantsNames);
	}
	
	// for 4 participants
	private void init(String [] participantsNames){
		
		Random alea = new Random();
		boolean freeCards[] = new boolean[8];
		
		// init free cards
		for(int i=0; i<8; i++)
			freeCards[i] = true;
		int product;
		// distribution
		for(int i=0;i<participants.length;i++){
			// give no cards and coins
			participants[i]=new Participant(i, participantsNames[i],new Hand(0,0,0,0,0,0,0,0),15);
			participants[i].setState(BUYER);
			
			// set the manager
			participants[i].setBidManager(this);
			// first serial
			do {
				product = alea.nextInt(8);
			}			
			while(!freeCards[product]); // until not yet distributed
			// give this card
			participants[i].getHand().giveCards(product+1, 4);
			// this cards are not free
			freeCards[product] = false;
			// second serial
			do {
				product = alea.nextInt(8);
			}			
			while(!freeCards[product]); // until not yet distributed
			// give this card
			participants[i].getHand().giveCards(product+1, 4);
			// this cards are not free
			freeCards[product] = false;			
		}		
	}
	
	private void initBids(){		
		for(int i=0; i<this.currentBids.length; i++){
			this.currentBids[i]=null;
		}
	}
	
	public void auctionAcard(int seller){
		this.currentSeller = this.participants[seller];
		LogManager.println(this.currentSeller.getName()+" met en vente "+nomsCartes[this.currentSeller.getSellingCard()]);
	}
	
	public void sell(Bid bid) {
		int sellingCard;
		Participant seller = this.currentSeller;

		Participant buyer = bid.getBuyer();
		int coins = bid.getCoins();
		int exchangeCard = bid.getExchangeCard();

		if (seller == null) { // DIAMOND card auction
			buyer.getHand().giveCards(DIAMOND, 1);
			buyer.giveCoins(-coins);
			this.setCurrentSeller(buyer);
			LogManager.println("Vente de la carte diamant � "+buyer.getName());
		}
		else {
			sellingCard = this.currentSeller.getSellingCard();

			// Give the card to buyer
			buyer.getHand().giveCards(sellingCard, 1);
			// remove his coins
			buyer.giveCoins(-coins);
			// remove the card to seller
			seller.getHand().giveCards(sellingCard, -1);
			// give coins to seller
			seller.giveCoins(coins);
			// A card is exchange ?
			if (exchangeCard != -1) {
				// give the card to seller;
				seller.getHand().giveCards(exchangeCard, 1);
				// remove the card to buyer
				buyer.getHand().giveCards(exchangeCard, -1);
			}
			LogManager.println("Vente de la carte "+nomsCartes[sellingCard]+" de "+seller.getName()+" � "+buyer.getName());
			
			if(buyer.isWinner() && seller.isWinner()){
				fini=true;
				this.winner=buyer.getParticipantNumber();
			}
			else if(buyer.isWinner()){
				fini=true;
				this.winner=buyer.getParticipantNumber();
			}
			else if(seller.isWinner()){
				fini=true;
				this.winner=seller.getParticipantNumber();
			}
			if(fini)
				LogManager.println(this.participants[this.winner]+" a gagn� !");
			else{ // new seller setting
				
				// if the buyer has offered a card
				if(exchangeCard == -1)
					// he becomes the new seller
					this.setCurrentSeller(buyer);
				// else the seller stays the current seller
			}
				
		}		
		this.currentSeller.setState(SELLER);
		this.currentSeller.setSellingCard(-1);
		for(int i=0;i<this.participants.length;i++){
			if(i != this.currentSeller.getParticipantNumber())
				this.participants[i].setState(BUYER);
		}
		this.currentBuyersNb=3;
		this.initBids();
	}
	
	/************** Implemented methods ***************************/
	
	public void bidUp(Bid bid) {
		
		this.currentBids[bid.getBuyer().getParticipantNumber()] = bid;
		
		Participant p=bid.getBuyer();
		String actionString=new String(p.getName()+" propose "+bid.getCoins()+" pi�ce(s)");
		if (bid.getExchangeCard() >= 0)
			LogManager.println(actionString+" et une carte "+nomsCartes[bid.getExchangeCard()]);
		else
			LogManager.println(actionString);	
	}
	
	public void takeOut(int participant){
		this.participants[participant].setState(OUT_OF_AUCTION);
		this.currentBuyersNb--;
		this.currentBids[participant]=null;		
		Bid bid=null;
		
		// the first game step : diamond card selling
		if((this.currentBuyersNb == 1) && (this.currentSeller == null)){			
			int i=0;
			while((i<currentBids.length) && (bid == null)){
				bid=currentBids[i];
				i++;
			}
			if (bid != null)
				this.sell(bid);
			else
				System.err.println("dans takeOut de Auction : pas de proposition");
		}
	}
	
	public void acceptBid(int seller, int buyer) {
		if(this.currentSeller == this.participants[seller]){
			this.sell(this.currentBids[buyer]);
		}
		else{
			System.err.println("erreur dans acceptBid de Auction");
		}
	}
	
	public Bid[] getCurrentBids() {
		return currentBids;
	}
	
	public Participant getCurrentSeller() {
		return currentSeller;
	}
	
	public int getCurrentSellerNumber() {
		return currentSeller.getParticipantNumber();
	}

	public void setCurrentSeller(Participant currentSeller) {
		this.currentSeller = currentSeller;
		this.currentSeller.setSellingCard(-1);
	}

	public Participant getParticipant(int i) {
		return participants[i];
	}
	
	public boolean hasProposedBid(int participant) {
		return (this.currentBids[participant] != null);
	}
	
	public int [] getOthersParticipantsNumbers(int participantNb) {
		
		int [] participantsNumbersTab = new int [3];
		int j=0;
		for(int i=0;i<this.participants.length;i++){
			if(this.participants[i].getParticipantNumber() != participantNb){
				participantsNumbersTab[j]=this.participants[i].getParticipantNumber();
				j++;
			}
		}
		return participantsNumbersTab;
	}
	
	public String getParticipantSituation(int i){
		Participant p=this.participants[i];
		String res=new String();
		int state=p.getState();
		
		if(state == SELLER){
			if (p.getSellingCard() != -1){
				res+=p.getName()+" vend "+nomsCartes[p.getSellingCard()];
			}
			else
				res+=p.getName()+" est vendeur";
		}
		else if(state == BUYER){
			if(this.currentBids[i] != null){
				res+=this.currentBids[i].toString();
			}
			else
				res+=p.getName()+" est acheteur";
		}
		else if(state == OUT_OF_AUCTION){
			res+=p.getName()+" s'est retir� de la vente";
		}
		return res;
	}
	
	public String toString(){
		String s=new String();
		for(int i=0;i<participants.length;i++){
			s+="\n"+participants[i];
		}
		return s;
	}
}
