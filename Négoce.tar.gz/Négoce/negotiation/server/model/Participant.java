package negotiation.server.model;

import negotiation.data.AuctionData;

public class Participant implements AuctionData{

	private String name;

	private int participantNumber;

	private Hand hand;

	private int coinsNumber;

	private BidManager bidManager;

	/** The card to sell; -1 if no sell */
	private int sellingCard;

	private int state;	
	
	public Participant(int participantNumber, String name, Hand hand, int cn) {
		this.participantNumber = participantNumber;
		this.name = name;
		this.hand = hand;
		this.coinsNumber = cn;
		this.state=BUYER;		
	}

	/**
	 * 
	 * @param coins
	 * @param card -1 if no card
	 */
	public void makeABid(int coins, int exchangeCard) {		
		Bid bid = new Bid();
		bid.setCoins(coins);
		bid.setExchangeCard(exchangeCard);
		bid.setBuyer(this);
		// propose the sell to bid manager
		bidManager.bidUp(bid);
	}
	
	public boolean isWinner(){
		return ((this.hand.isComplete()) && (this.coinsNumber >= 10));
	}
	
	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}

	/************* Getters and Setters *********************/

	public int getCoinsNumber() {
		return coinsNumber;
	}

	public void setCoinsNumber(int coinsNumber) {
		this.coinsNumber = coinsNumber;
	}

	public Hand getHand() {
		return hand;
	}

	public void setHand(Hand hand) {
		this.hand = hand;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void giveCoins(int nb) {
		coinsNumber += nb;
	}

	public BidManager getBidManager() {
		return bidManager;
	}

	public void setBidManager(BidManager bidManager) {
		this.bidManager = bidManager;
	}

	public int getSellingCard() {
		return sellingCard;
	}

	public void setSellingCard(int sellingCard) {
		this.sellingCard = sellingCard;
	}

	public int getParticipantNumber() {
		return participantNumber;
	}

	public void setParticipantNumber(int participantNumber) {
		this.participantNumber = participantNumber;
	}
	
	/*******************************************************/
	
	public String toString() {
		return this.name + "\n" + this.hand + "coins: " + this.coinsNumber+"\n";
	}
}
