package negotiation.server.model;

import negotiation.data.AuctionData;

public class Bid implements AuctionData{
	
	private int coins;

	private int exchangeCard;

	private Participant buyer;

	public Bid() {
		this.coins = 0;
		this.exchangeCard = -1;
		this.buyer = null;
	}
	
	public Bid(int coins, int exchangeCard, Participant participant) {
		this.coins=coins;
		this.exchangeCard=exchangeCard;
		this.buyer=participant;		
	}

	public Participant getBuyer() {
		return buyer;
	}

	public void setBuyer(Participant buyer) {
		this.buyer = buyer;
	}

	public int getCoins() {
		return coins;
	}

	public void setCoins(int coins) {
		this.coins = coins;
	}

	public int getExchangeCard() {
		return exchangeCard;
	}

	public void setExchangeCard(int exchangeCard) {
		this.exchangeCard = exchangeCard;
	}
	
	public String toString(){
		String res=this.buyer.getName()+" propose ";
		if((this.coins != 0) && (this.exchangeCard == -1)){
			res+=this.coins+" pi�ces";
		}
		else if((this.coins != 0) && (this.exchangeCard != -1))
			res+="une carte "+nomsCartes[this.exchangeCard]+" et "+this.coins+" pi�ces";
		else
			res+="une carte "+nomsCartes[this.exchangeCard];
		return res;
	}
}
