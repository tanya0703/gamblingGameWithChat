package negotiation.client.view;


import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;


public class DecisionPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	private JButton bidUpButton, leakButton;
	
	public DecisionPanel(ActionListener listen){
		
		GridLayout gl=new GridLayout(2,1);
		gl.setVgap(10);
	    this.setLayout(gl);
	    
    
	    this.bidUpButton = new JButton("Ench�rir");
	    this.bidUpButton.setName("bidUp");
	    this.bidUpButton.addActionListener(listen);
	    this.add(this.bidUpButton);
	    this.leakButton = new JButton("Se retirer de la vente");
	    this.leakButton.setName("leak");
	    this.leakButton.addActionListener(listen);
	    this.add(this.leakButton);
	    
	    this.setBackground(Color.white);
	  }
	
	public void activate(){
		this.bidUpButton.setEnabled(true);
		this.leakButton.setEnabled(true);
	}
	
	public void inactivate(){
		this.bidUpButton.setEnabled(false);
		this.leakButton.setEnabled(false);
	}
}
