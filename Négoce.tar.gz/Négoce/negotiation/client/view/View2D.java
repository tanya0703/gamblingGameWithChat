package negotiation.client.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

import negotiation.data.AuctionData;
import negotiation.data.ColorData;
import negotiation.server.controller.NegotiationControllerIf;
import negotiation.server.controller.NegotiationView;

public class View2D extends UnicastRemoteObject implements NegotiationView, AuctionData, ColorData{

	private NegotiationControllerIf controller;
	private JFrame frame;
	private String name;
	private int participantNumber;
	private int [] othersParticipantNumber;	
	
	private static final long serialVersionUID = 1L;

	private ParticipantPanel p1, p2, p3;
	
	private Vector<ParticipantPanel> othersParticipantsPanel;
	
	private BidActionsPanel bidActionsPanel;
	private SellActionsPanel sellActionsPanel;
	
	private CardsPanel cardsPanel;
	private int [] cards;
	private CardsPanel allCards;
	
	private CoinsPanel coinsPanel;
	
	private ActionListener listen;
	private KeyListener keysListen;
	
	private ChatEditor chatEditor;
	private JTextArea messageWindow;
	
	private JFrame waitWindow;
	
	public View2D()throws RemoteException{
		initWaitWindow();
	}
	
	private void initWaitWindow(){
		this.waitWindow=new JFrame("En attente");		
		this.waitWindow.setSize(200, 200);
		
		JTextArea infos = new JTextArea();
		infos.setBackground(Color.lightGray);
		infos.setForeground(Color.black);
		infos.setText("Veuillez patienter :\nen attente de connexion des autres participants");
		this.waitWindow.getContentPane().add(infos, BorderLayout.CENTER);
		
		this.waitWindow.setEnabled(false);		
		
		Dimension tailleEcran = Toolkit.getDefaultToolkit().getScreenSize();
		int largeurEcran = tailleEcran.width;
		int hauteurEcran = tailleEcran.height;
		
		int largeur = this.waitWindow.getSize().width;
		int hauteur = this.waitWindow.getSize().height;

		int xPos = (largeurEcran - largeur) / 2;
		int yPos = ((hauteurEcran - hauteur) / 2) - 10;
		this.waitWindow.setLocation(xPos, yPos);
		this.waitWindow.pack();
		this.waitWindow.setVisible(true);		
	}	
	
	public void init(int [] othersNumbers, int participantNumber, NegotiationControllerIf controller)throws RemoteException{
		this.waitWindow.dispose();
		
		try {
			this.frame=new JFrame(controller.getName(participantNumber));
		} catch (HeadlessException e1) {
			e1.printStackTrace();
		} catch (RemoteException e1) {
			e1.printStackTrace();
		}

		this.frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		this.controller=controller;
		this.participantNumber=participantNumber;
		try {
			this.name=controller.getName(participantNumber);
		} catch (RemoteException e1) {
			e1.printStackTrace();
		}
		this.listen = new theListener();
		this.othersParticipantsPanel=new Vector<ParticipantPanel>();		
		this.othersParticipantNumber=othersNumbers;
		
		this.frame.getContentPane().setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		this.cards=new int [9];
		for(int i=0;i<this.cards.length;i++){
			this.cards[i]=1;
		}
		this.allCards=new CardsPanel();
		
		c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth =GridBagConstraints.REMAINDER;
		c.gridheight = 1;
		c.weighty = 0;
		c.weightx = 0;
		c.fill = GridBagConstraints.VERTICAL;
		this.frame.getContentPane().add(allCards, c);
		
		
		try {
			this.p1 = new ParticipantPanel(controller.getName(othersParticipantNumber[0]), othersParticipantNumber[0], participantsColors[othersParticipantNumber[0]],listen);
		} catch (RemoteException e1) {
			e1.printStackTrace();
		}
		c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 1;
		c.gridheight=1;
		c.gridwidth=3;		
		c.weighty = 0.3;
		c.weightx = 0.3;
		c.fill = GridBagConstraints.NONE;
		this.frame.getContentPane().add(p1, c);

		try {
			this.p2 = new ParticipantPanel(controller.getName(othersParticipantNumber[1]), othersParticipantNumber[1], participantsColors[othersParticipantNumber[1]],listen);
		} catch (RemoteException e1) {
			e1.printStackTrace();
		}
		c = new GridBagConstraints();
		c.gridx = 3;
		c.gridy = 1;
		c.gridheight=1;
		c.gridwidth=3;		
		c.weighty = 0.3;
		c.weightx = 0.3;
		c.fill = GridBagConstraints.NONE;
		this.frame.getContentPane().add(p2, c);

		try {
			this.p3 = new ParticipantPanel(controller.getName(othersParticipantNumber[2]), othersParticipantNumber[2], participantsColors[othersParticipantNumber[2]],listen);
		} catch (RemoteException e1) {
			e1.printStackTrace();
		}
		c = new GridBagConstraints();
		c.gridx = 6;
		c.gridy = 1;
		c.gridheight=1;
		//c.gridwidth=3;		
		c.weighty = 0.3;
		c.weightx = 0.3;
		c.gridwidth =GridBagConstraints.REMAINDER;
		c.fill = GridBagConstraints.NONE;
		this.frame.getContentPane().add(p3, c);
		
		this.othersParticipantsPanel.add(p1);
		this.othersParticipantsPanel.add(p2);
		this.othersParticipantsPanel.add(p3);

		this.chatEditor=new ChatEditor();
		this.chatEditor.setBorder(new LineBorder(Color.black, 1));
		
		JPanel panelChat = new JPanel(new GridLayout(1,1));
		JScrollPane scroll = new JScrollPane(this.chatEditor);
		panelChat.add(scroll);
		
		c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 2;
		c.gridwidth=6;
		c.gridheight=3;				
		c.weighty = 0.3;
		c.weightx = 0;
		c.fill = GridBagConstraints.BOTH;
		this.frame.getContentPane().add(panelChat, c);
		
		this.messageWindow = new JTextArea("", 10000, 10000);
		this.messageWindow.setFocusable(true);
		this.keysListen = new KeyBoardKeysListener();
		this.messageWindow.addKeyListener(this.keysListen);

		this.messageWindow.setBorder(new LineBorder(Color.black, 1));
		c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 5;
		c.gridwidth=6;
		c.gridheight=1;				
		c.weighty = 0.3;
		c.weightx = 0.3;
		c.fill = GridBagConstraints.BOTH;
		this.frame.getContentPane().add(this.messageWindow, c);
		
		this.sellActionsPanel = new SellActionsPanel(listen);
		c = new GridBagConstraints();
		c.gridx = 6;
		c.gridy = 2;
		c.gridwidth =GridBagConstraints.REMAINDER;
		//c.gridwidth=3;
		c.gridheight=2;				
		c.weighty = 0.3;
		c.weightx = 0;
		c.fill = GridBagConstraints.NONE;
		this.frame.getContentPane().add(sellActionsPanel, c);

		this.bidActionsPanel = new BidActionsPanel(listen);
		c = new GridBagConstraints();
		c.gridx = 6;
		c.gridy = 4;
		c.gridwidth =GridBagConstraints.REMAINDER;
		//c.gridwidth=3;
		c.gridheight=2;				
		c.weighty = 0.3;
		c.weightx = 0.3;
		c.fill = GridBagConstraints.NONE;
		this.frame.getContentPane().add(this.bidActionsPanel, c);
		
		this.cardsPanel=new CardsPanel();
		c = new GridBagConstraints();
		c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 6;
		c.gridwidth=8;
		c.gridheight =GridBagConstraints.REMAINDER;
		c.weighty = 0;
		c.weightx = 0;
		c.fill = GridBagConstraints.HORIZONTAL;
		this.frame.getContentPane().add(this.cardsPanel, c);
		
		this.coinsPanel=new CoinsPanel();
		c = new GridBagConstraints();
		c.gridx = 8;
		c.gridy = 6;
		//c.gridwidth =GridBagConstraints.REMAINDER;
		//c.gridheight =GridBagConstraints.REMAINDER;		
		c.weighty = 0;
		c.weightx = 0;
		//c.fill = GridBagConstraints.BOTH;
		this.frame.getContentPane().add(this.coinsPanel, c);
		
		try {
			this.refresh();
		} catch (RemoteException e) {
			System.err.println("RemoteException attrapp�e dans constructeur de View2D : "+e);
		}
		
		this.frame.pack();
		this.frame.setSize(this.frame.getLayout().preferredLayoutSize(this.frame));
		center();
		this.frame.setVisible(true);
		this.frame.setResizable(true);
		this.messageWindow.requestFocus();		
	} // end of constructor

	void center() {
		Dimension tailleEcran = Toolkit.getDefaultToolkit().getScreenSize();
		int largeurEcran = tailleEcran.width;
		int hauteurEcran = tailleEcran.height;
		this.frame.setSize(largeurEcran - 10, hauteurEcran - 40);

		int largeur = this.frame.getSize().width;
		int hauteur = this.frame.getSize().height;

		int xPos = (largeurEcran - largeur) / 2;
		int yPos = ((hauteurEcran - hauteur) / 2) - 10;
		this.frame.setLocation(xPos, yPos);
	}
	
	public void refresh() throws RemoteException{
		int otherNb;
		ParticipantPanel otherPanel;
		// update participant enabled commands on the IHM
		int state=controller.getState(participantNumber);		
		
		if(state == SELLER)
			this.setSellerView();
		else if(state == BUYER)
			this.setBuyerView();
		else if(state == OUT_OF_AUCTION)
			this.setOutOfAuctionView();
		
		// update others participants views
		for(int i=0; i<this.othersParticipantNumber.length;i++){
			
			otherNb=othersParticipantNumber[i];
			state=controller.getState(otherNb);
			otherPanel=this.othersParticipantsPanel.get(i);
			
			if(state == OUT_OF_AUCTION){
				if(controller.getState(participantNumber) == SELLER)
					otherPanel.inactivate();
			}
			otherPanel.setPositionLabel(this.controller.getParticipantSituation(otherNb));
			otherPanel.setCoinsLabel(this.controller.getCoinsNumber(otherNb));
		}
		// update coins number and card types numbers
		this.cardsPanel.refresh(controller.getCards(this.participantNumber));
		this.coinsPanel.refresh(controller.getCoinsNumber(this.participantNumber));
		this.allCards.refresh(this.cards);		
		this.frame.setTitle(this.controller.getParticipantSituation(this.participantNumber));		
	}

	public void setBuyerView() throws RemoteException{
		this.p1.inactivate();
		this.p2.inactivate();
		this.p3.inactivate();
		this.bidActionsPanel.activate();
		this.sellActionsPanel.inactivate();
	}

	public void setSellerView() throws RemoteException{
		this.p1.activate();
		this.p2.activate();
		this.p3.activate();
		this.sellActionsPanel.activate();
		this.bidActionsPanel.inactivate();
	}
	
	public void setOutOfAuctionView() throws RemoteException{
		this.p1.inactivate();
		this.p2.inactivate();
		this.p3.inactivate();
		this.sellActionsPanel.inactivate();
		this.bidActionsPanel.inactivate();
	}
	
	class KeyBoardKeysListener implements KeyListener {
		public void keyTyped(KeyEvent e) {
			//Invoked when a key has been typed. 
			//This event occurs when a key press is followed by a key release.
		}

		public void keyPressed(KeyEvent e) {
			//Invoked when a key has been pressed.
			if (e.getKeyCode() == KeyEvent.VK_ENTER) {
				//System.out.println("entr�e tap�e : " + messageWindow.getText());				
				try {
					controller.sendMessage(name,participantNumber,messageWindow.getText());
				} catch (RemoteException e1) {
					e1.printStackTrace();
				}
			}
		}

		public void keyReleased(KeyEvent e) {
			if (e.getKeyCode() == KeyEvent.VK_ENTER) {
				messageWindow.setText("");
			}
		}
	}
	
	class theListener implements ActionListener{
		
		public theListener(){
		}
		
		public void actionPerformed(ActionEvent e){
			Object src=((JComponent)e.getSource());
			String sourceName;
			
			if(src instanceof JButton){
				sourceName=((JButton)src).getName();
				
				if(sourceName.equals("sell")){
					System.out.print(name+" propose une vente");
					try {
						controller.auctionAcard(participantNumber, sellActionsPanel.getTypeCard());
					} catch (RemoteException e1) {
						System.err.print("RemoteException attrap�e : sell dans actionPerformed du listener de View2D"+e);
					}
				}
				else if(sourceName.equals("bidUp")){
					System.out.print(name+" propose une ench�re");				
					try {
						controller.bidUp(participantNumber, bidActionsPanel.getTypeCard(),bidActionsPanel.getCoinsNb());
					} catch (RemoteException e1) {
						System.err.print("RemoteException attrap�e : bidUp dans actionPerformed du listener de View2D"+e);
					}
				}					
				else if(sourceName.equals("leak")){
					System.out.println(name+" se retire de la vente");
					try {
						controller.takeOut(participantNumber);
					} catch (RemoteException e1) {
						System.out.print("RemoteException attrap�e : leak dans actionPerformed du listener de View2D"+e);
					}
				}
				else if((sourceName.substring(sourceName.length()-6, sourceName.length())).equals("accept")){
					
					try {						
						controller.acceptBid(participantNumber,Integer.parseInt(sourceName.substring(0, 1)));
					} catch (NumberFormatException e2) {
						e2.printStackTrace();
					} catch (RemoteException e2) {
						e2.printStackTrace();
					}					
				}
			}
			else if(src instanceof JComboBox){
			
				//System.out.println("selection de "+((JComboBox)src).getSelectedItem()+" "+((JComboBox)src).getSelectedIndex());			
			}
			if(!(src instanceof JTextField))
				messageWindow.requestFocus();
			
		}
	} // end class theListener

	public void receiveMessage(String hour, String user, String message, int participant) throws RemoteException {
		this.chatEditor.addText("[" + hour + "] " + user + " : "+message+"\n",htmlColors[participant]);
	}
}
