package negotiation.client.view;


import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

import negotiation.data.AuctionData;



public class SellActionsPanel extends JPanel implements AuctionData{

	
	static final String picturesDir="pictures";	// pictures directory
	static final String [] comboNames={"Aucune","Bijoux","Cigares","Caf�","Diamant","Epices","Livres","Miel","Th�","Vin"};
	
	private static final long serialVersionUID = 1L;
	
	private JButton sellButton;
	private JComboBox comboCards;
	
	public SellActionsPanel(ActionListener listen) {
		this.setLayout(new GridBagLayout());
	    GridBagConstraints c = new GridBagConstraints();
	    
	    JLabel cardLabel = new JLabel("Carte propos�e � la vente : ");
	
	    c.weightx = c.weighty=1.0;
	    c.ipadx = 20;
	    c.gridx = 0;
	    c.gridy = 0;
	    c.gridwidth = 2;
	    c.gridheight = 1;
	    //c.anchor=GridBagConstraints.NORTH;
	    c.fill = GridBagConstraints.NONE;
	    c.insets = new Insets(10, 10, 10, 10);
	    this.add(cardLabel,c);
	    
	    this.comboCards = new JComboBox(comboNames);
	    this.comboCards.setSelectedIndex(0);
	    this.comboCards.setName("cardChoiceToSell");
	    this.comboCards.addActionListener(listen);
	    c.gridx = 2;
	    c.gridy = 0;
	    c.gridwidth = 1;
	    c.gridheight = 1;
	    //c.anchor=GridBagConstraints.NORTH;
	    //c.insets = new Insets(30, 50, 10, 50);
	    //c.insets = new Insets(10, 30, 5, 30);
	    this.add(comboCards,c);
	    
	    this.sellButton = new JButton("Mettre en vente");
	    this.sellButton.setName("sell");
	    this.sellButton.addActionListener(listen);
	    c.gridx = 0;
	    c.gridy = 1;
	    c.gridwidth = 3;
	    c.gridheight = 1;
	    this.add(sellButton,c);
	    
	    this.setBackground(Color.white);
	    this.setBorder(new LineBorder(Color.black,1));
	    this.setSize(getLayout().preferredLayoutSize(this));
	}
	
	public int getTypeCard(){
		int res = -1;
		
		switch(this.comboCards.getSelectedIndex()){
			case 0 : res=-1; break;
			case 1 : res=JEWEL; break;
			case 2 : res=CIGAR; break;
			case 3 : res=COFFEE; break;
			case 4 : res=DIAMOND; break;
			case 5 : res=SPICE; break;
			case 6 : res=BOOK; break;
			case 7 : res=HONEY; break;
			case 8 : res=TEA; break;
			case 9 : res=WINE; break;
		}
		return res;
	}
	
	public void activate(){
		this.sellButton.setEnabled(true);
		this.comboCards.setEnabled(true);
	}
	
	public void inactivate(){
		this.sellButton.setEnabled(false);
		this.comboCards.setEnabled(false);
	}
}
