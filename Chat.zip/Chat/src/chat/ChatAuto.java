package chat;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

public class ChatAuto {;
    private String userName;
 
    public ChatAuto() {

    }
 
    public void execute() {
        try {
            Socket socket = new Socket("localhost", 9099);
 
            System.out.println("Connected to the chat server");
            ReadThreadAuto rt = new ReadThreadAuto(socket, this);
            WriteThreadAuto wta = new WriteThreadAuto(socket, this);
            wta.sendName();
            while (true) {
            	String messageRead = rt.read();
            	if (messageRead == null) {
                	messageRead = "Hello ai";
                }
                wta.answering(messageRead);
            	
            }
           // rt.forNotify(messageRead, resp);
	        //messageRead = rt.giveMessageRead();
	        //wta.answering(messageRead);
	                //rt.start();
    	           // this.forNotify(messageRead);
	    	           
	    	           // this.forNotify(messageRead);
	    	           // String[] words = messageRead.split(" ");
	    	           // System.out.println("The readed message: " + messageRead);
	    	           // wta.answering(messageRead);
	    	          //  this.forNotify(messageRead);
	    	          //  for (int i=0; i < words.length;i++){
	    	           // 	System.out.println(words[i]);
	    	           // 	if ((words[i].equals("ai")) || (words[i].equals("AI"))){
	    	           // 		synchronized(messageRead) {
	    	           // 			System.out.println("I was in the synchronzed thing!");
	    	           // 			messageRead.notify();		
	    	           // 		}
	    	           // 	}
	    	           // }
	    	            //System.out.println("Readed message: " + messageRead); 
	 	           		//wta.answering(messageRead);	            } while (messageRead.equals("bye ai"));
	            	//try {
	            		//messageRead.wait();
	            //	for (int i=0; i < words.length;i++){
            	//		System.out.println(words[i]);
	            //		if ((words[i] == "ai") || (words[i]=="AI")){
	            //			System.out.println();
	            			//messageRead.notify();
	            //				}
		        //	}
	            	//} catch (InterruptedException e) {
	                //e.printStackTrace();
	            //	}
	            //System.out.println("Readed message: " + messageRead); 
	           //new WriteThreadAuto(socket, this).answering(messageRead);
            //}
        } catch (UnknownHostException ex) {
            System.out.println("Server not found: " + ex.getMessage());
        } catch (IOException ex) {
            System.out.println("I/O Error: " + ex.getMessage());
        }
 
    }
 
    void setUserName(String userName) {
        this.userName = userName;
    }
 
    String getUserName() {
        return this.userName;
    }
 
 
    public static void main(String[] args) {
        ChatAuto client = new ChatAuto();
        client.execute();
    }
    public void forNotify(String message) {
        String[] words = message.split(" ");
    	for (int i=0; i < words.length;i++){
        	System.out.println(words[i]);
        	if ((words[i].equals("ai")) || (words[i].equals("AI"))){
        		synchronized(message) {
        			System.out.println("I was in the synchronzed thing!");
        			message.notifyAll();		
        		}
        	}
        }
    }
}
