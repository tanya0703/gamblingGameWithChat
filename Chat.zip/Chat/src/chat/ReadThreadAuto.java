package chat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;

public class ReadThreadAuto extends Thread{
	private BufferedReader reader;
	private String messageRead ;
    private Socket socket;
    private ChatAuto client;
 
    public ReadThreadAuto(Socket socket, ChatAuto client) {
        this.socket = socket;
        this.client = client;
        this.messageRead = null;
 
        try {
            InputStream input = socket.getInputStream();
            reader = new BufferedReader(new InputStreamReader(input));
        } catch (IOException ex) {
            System.out.println("Error getting input stream: " + ex.getMessage());
            ex.printStackTrace();
        }
    }
    
    //public String giveMessageRead() {
    //	return this.messageRead;
    //}
    
    public String read() {
      //  while (true) {
            try {
                this.messageRead = reader.readLine();
                System.out.println("\n" + this.messageRead);
                
                if (client.getUserName() != null) {
                    System.out.print("[" + client.getUserName() + "]: ");
                }
            } catch (IOException ex) {
                System.out.println("Error reading from server: " + ex.getMessage());
                ex.printStackTrace();
            }
            return this.messageRead;
        }
   // }
    
    public void forNotify(String message, Answer ans) {
        String[] words = message.split(" ");
		System.out.println("I was in the forNotify thing!");
    	for (int i=0; i < words.length;i++){
        	if ((words[i].equals("ai")) || (words[i].equals("AI"))){
        		synchronized(ans) {
        			System.out.println("I was in the synchronzed thing!");
        			ans.notifyAll();        			
        			//System.out.println("I was in the synchronzed thing!");
		
        		}
        	}
        }
    }
}
