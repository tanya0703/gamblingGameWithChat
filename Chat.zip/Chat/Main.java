/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
      Scanner reader = new Scanner(System.in);
      System.out.println("Do you want to participate?");
      String r = reader.next();
      if (r.equals("yes")) {
        System.out.println("Yes, I will participate");
        System.out.println("How much money can you pay about that? ");
        int n = reader.nextInt();
        System.out.println("How many cards can you propose about that? ");
        int p = reader.nextInt();
        String response;
        if (n==1) && (p != 1){
          response = String.format("I'm proposing 1 piece and %d cards for your card",p);
        } else if ((n==1) && (p==1)) {
          response = String.format("I'm proposing 1 piece and 1 card in ",p);
        }
        response = String.format("I'm giving %d pieces and %d cards for your card",n,p);
        System.out.println(response);
        reader.close();
      }
        else {
          System.out.println("I won’t participate in this part.");
          reader.close();
      }
    }

}
