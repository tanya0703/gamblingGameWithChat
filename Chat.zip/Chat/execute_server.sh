java -cp .:./bin bin.chat.ChatServer
