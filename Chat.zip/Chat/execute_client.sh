java -cp .:./bin bin.chat.ChatClient
