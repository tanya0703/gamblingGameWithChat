java -cp .:./bin bin.chat.ChatAuto
