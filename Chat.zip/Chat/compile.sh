javac -cp .:./bin src/chat/*.java
