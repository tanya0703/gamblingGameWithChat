java -cp .:./negotiation negotiation.main.ClientExec
