java -cp .:./negotiation negotiation.main.ServerExec
