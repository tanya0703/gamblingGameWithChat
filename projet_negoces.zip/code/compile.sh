javac -cp .:./negotiation negotiation/data/*.java
javac -cp .:./negotiation negotiation/client/view/*.java
javac -cp .:./negotiation negotiation/server/controller/*.java
javac -cp .:./negotiation negotiation/server/model/*.java
javac -cp .:./negotiation negotiation/ai/*.java
javac -cp .:./negotiation negotiation/main/*.java
