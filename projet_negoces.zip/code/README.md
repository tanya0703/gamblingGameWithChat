# INSTRUCTIONS POUR LE LANCEMENT DU JEU DE NEGOCES

## PREPARATION DE L'ENVIRONNEMENT

Le programme nécessite une version propriétaire de Java afin d'être correctement
compilé et exécuté.

Voici les commandes à lancer dans un terminal pour installer la version propriétaire
de Java 8 :

```
sudo add-apt-repository -y ppa:webupd8team/java
sudo apt-get update
sudo apt-get install -y oracle-java8-installer
```

## COMPILATION

Pour compiler l'ensemble du code source du jeu il faut ouvrir un terminal et
lancer l'instruction suivante :

```
./compile.sh
```

## LANCEMENT DU JEU

### LANCEMENT DU SERVEUR

Le serveur est à lancer en premier, avant tout lancement de programme client.

Pour le lancer, il faut ouvrir un premier terminal T1 et exécuter la commande suivante :

```
./execute_server.sh
```

Le terminal T1 doit rester ouvert.

### LANCEMENT DE L'AGENT INTELLIGENT

Pour jouer face à l'agent intelligent, il faut le lancer en premier, avant les
autres programmes joueur (seulement pour que le nom "AI" corresponde à l'agent).

#### Personnalités

L'agent intelligent dispose de différentes personnalités :

  * **Neutre** : L'agent intelligent a une stratégie neutre, il ne prend pas trop
  de risque dans les négociations mais est assez ambitieux ;
  * **Prudent** : L'agent intelligent a une stratégie prudente, il ne prend pas trop de risque dans les négociations. Il accepte les propositions peu intéressantes pour lui et génère des propositions de faible valeur ;
  * **Ambitieux** : L'agent intelligent a une stratégie ambitieuse, il prend des risques dans les négociations. Il accepte seulement les propositions  intéressantes pour lui et peut génèrer des propositions de haute valeur.

#### Execution du programme de l'agent intelligent

Pour lancer le programme de l'agent avec la personnalité **neutre**, il faut ouvrir un nouveau terminal T2 et lancer la commande suivante :

```
./execute_ai.sh
```

Si l'agent doit être configuré avec une personnalité non neutre, il faut ouvrir un nouveau terminal T2 et lancer une des commandes suivantes :

  * **Prudent** : ```./execute_ai.sh careful```
  * **Ambitieux** : ```./execute_ai.sh ambitious```

Le terminal T2 doit rester ouvert.

### LANCEMENT DU PROGRAMME JOUEUR

Si le programme de l'agent intelligent a été lancé, il faut ouvrir trois nouveaux
terminaux et lancer dans chacun d'entre eux la commande suivante :

```
./execute_client.sh
```

Si le jeu doit uniquement être joué entre joueurs humains, il faut ouvrir quatre
terminaux et lancer dans chacun d'entre eux la commande précédente.

Ces terminaux doivent rester ouvert le temps de la partie.

## INFORMATIONS CONCERNANT L'AGENT INTELLIGENT

L'agent intelligent a été conçu et développé comme possédant les mêmes informations
qu'un joueur humain. C'est à dire que sa connaissance des mains adverses s'acquière lorsque les adversaires dévoilent leurs cartes. L'agent intelligent n'a jamais
directement accès aux mains des joueurs.
