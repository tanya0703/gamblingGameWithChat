java -cp .:./negotiation negotiation.main.AiExec $1
