package negotiation.main;

public interface RMIData {

	// file name containing port and ip server to use
	public final static String IpServerFile = "server.txt";

	// labo	public final static String server = "192.168.20.200";
	// public final static String server = "88.162.12.181";
	
	public final static String name = "negotiation";
}
