package negotiation.main;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.rmi.Naming;
import java.rmi.NotBoundException;

import negotiation.ai.*;
import negotiation.server.controller.NegotiationControllerIf;


public class AiExec implements RMIData{

	public static void main(String argv []){

		BufferedReader bufferedReader = null;
		FileReader fileReader = null;
		String serverIp, port;

		try {
			// reading port and ip server to use
			fileReader=new FileReader(IpServerFile);
			bufferedReader = new BufferedReader(fileReader);
			serverIp = bufferedReader.readLine();
			port = bufferedReader.readLine();

			// controller retrieval
			NegotiationControllerIf controller=(NegotiationControllerIf)Naming.lookup("rmi://"+serverIp+":"+port+"/"+name);

			Personality personality = null;

			if(argv.length==0)
				personality = new Personality("normal");
			else
				personality = new Personality(argv[0]);

			// view creation
			Agent agent=new Agent(personality);

			controller.connect(agent);

			bufferedReader.close();
			fileReader.close();

		} catch (FileNotFoundException e1) {
			System.err.println("Fichier introuvable");
			e1.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		catch (NotBoundException e) {
			e.printStackTrace();
		}
		catch (NoCorrespondingPersonalityException e) {
			e.printStackTrace();
		}

	}// end main
}
