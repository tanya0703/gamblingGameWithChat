package negotiation.server.model;

import negotiation.data.AuctionData;

public interface BidManager extends AuctionData {
	public void bidUp(Bid bid);
}
