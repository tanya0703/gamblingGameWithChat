package negotiation.server.model;

import java.util.*;

import negotiation.data.AuctionData;

public class Hand implements AuctionData {

	private int [] hand;	// cards numbers by type, for example [1,4,4,0,0,0,0,0,0]

	public Hand(int book, int cigar, int coffee, int honey, int jewel, int spice, int tea, int wine){
		this.hand=new int[]{0,book,cigar,coffee,honey,jewel,spice,tea,wine};
	}

	public Hand(int [] hand){
		this.hand=hand;
	}

	public void setNb(int cardType, int nb){
		this.hand[cardType]=nb;
	}

	public int getNb(int cardType){
		return this.hand[cardType];
	}

	public void giveCards(int cardType, int nbNewCard){
		this.hand[cardType] += nbNewCard;
	}

	public boolean hasCard(int cardType){
		return (this.hand[cardType] > 0);
	}

	public Integer[] getCardsInHand() {
		List<Integer> cardsList = new ArrayList<Integer>();
		for(int i=0; i<9; i++){
      if(hasCard(i))
				cardsList.add(i);
    }
		Integer[] cards = new Integer[cardsList.size()];
		cards = cardsList.toArray(cards);
		return cards;
	}

	public int getCardMostPresent() {
		int max = 0;
		int cardMostPresent = 0;
		for(int card=0; card<9; card++) {
			if(this.getNb(card)>max) {
				max = this.getNb(card);
				cardMostPresent = card;
			}
		}
		return cardMostPresent;
	}

	/** Return true if the hand can win (if there are at least 8 different cards) */
	public boolean isComplete(){
		boolean res=false;
		int differentCardsNumber=0;
		if(this.getCardsNumber() >= 8){
			for(int i=0;i<9;i++){
				if(this.hand[i] >= 1){
					differentCardsNumber++;
				}
			}
			if(differentCardsNumber >= 8)
				res=true;
		}
		return res;
	}

	public boolean isCompleteIf(int typeCard){
		int[] dest = new int[9];
		System.arraycopy( this.hand, 0, dest, 0, this.hand.length );
		Hand newHand = new Hand(dest);
		newHand.setNb(typeCard, newHand.getNb(typeCard)+1);
		return newHand.isComplete();
	}

	public int getCardsNumber(){
		int nbr = 0;
		for(int i=0;i<9;i++){
			nbr+= hand[i];
		}
		return nbr;
	}

	public String toString(){
		return new String("DIAMOND: "+this.hand[DIAMOND]+", "+"BOOK: "+this.hand[BOOK]+", "+"CIGAR: "
				+this.hand[CIGAR]+", "+"COFFEE: "+this.hand[COFFEE]+", "+"HONEY: "+this.hand[HONEY]+", "+"JEWEL: "
				+this.hand[JEWEL]+", "+"SPICE: "+this.hand[SPICE]+", "+"TEA: "+this.hand[TEA]+", "+"WINE: "+this.hand[WINE]+ "\n"
				+"Total : "+ this.getCardsNumber() + " cards\n");
	}
}
