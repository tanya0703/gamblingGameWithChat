package negotiation.server.controller;

import java.rmi.Remote;
import java.rmi.RemoteException;


public interface NegotiationView extends Remote{
	public void init(int [] othersNumbers, int participantNumber, NegotiationControllerIf controller)throws RemoteException;
	public void refresh() throws RemoteException;
	public void setBuyerView() throws RemoteException;
	public void setSellerView() throws RemoteException;
	public void setOutOfAuctionView() throws RemoteException;
	public void receiveMessage(String hour, String user, String message, int participant) throws RemoteException;	
}
