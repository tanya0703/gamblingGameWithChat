package negotiation.server.controller;

import java.rmi.Remote;
import java.rmi.RemoteException;


public interface NegotiationControllerIf extends Remote{

	public void connect(NegotiationView view) throws RemoteException;
	
	public void sendMessage(String user, int participantNumber, String message) throws RemoteException;
	
	public String getName(int participantNumber)throws RemoteException;

	public int getCoinsNumber(int participantNumber)throws RemoteException;

	public int[] getCards(int participantNumber)throws RemoteException;

	public int getState(int participantNumber)throws RemoteException;

	public String getParticipantSituation(int otherNb)throws RemoteException;

	public void auctionAcard(int participantNumber, int typeCard)throws RemoteException;

	public void bidUp(int participantNumber, int typeCard, int coinsNb)throws RemoteException;

	public void takeOut(int participantNumber)throws RemoteException;

	public void acceptBid(int participantNumber, int i)throws RemoteException;
}
