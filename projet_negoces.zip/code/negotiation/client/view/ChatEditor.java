package negotiation.client.view;

import javax.swing.JEditorPane;

public class ChatEditor extends JEditorPane{

	

	private StringBuffer chatText;
	private static final long serialVersionUID = 1L;

	public ChatEditor(){
		  super("text/html","");
		  this.chatText=new StringBuffer();
	      this.setEditable(false);
	     // editor.setText("<H3
		// color=red>Help</H3><center></center><li>AAArg<li><i
		// color=green>Two</i><li><u>Three</u>");
	    // JScrollPane scrollPane = new JScrollPane(editor);      
	  }

	public void addText(String text, String color) {
		this.chatText.append("<font color="+color+">"+text+"</font><br>");
		this.setText(this.chatText.toString());
	}
}