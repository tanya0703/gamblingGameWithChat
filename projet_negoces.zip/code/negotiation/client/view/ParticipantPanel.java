package negotiation.client.view;


import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;


public class ParticipantPanel extends JPanel {
	
	JButton acceptButton;
	JLabel coinsLabel;
	JLabel positionLabel;
	
	
	private static final long serialVersionUID = 1L;

	ParticipantPanel(String name, int number, Color participantColor, ActionListener listen) {

		this.setLayout(new GridBagLayout());
	    GridBagConstraints c = new GridBagConstraints();
	    
	    JLabel nameLabel = new JLabel(name);
	    c.weightx = 1;
	    c.ipadx = 20;
	    c.gridx = 0;
	    c.gridy = 0;
	    c.gridwidth = 1;
	    c.gridheight = 1;
	    //c.insets = new Insets(30, 50, 10, 50);
	    c.insets = new Insets(10, 30, 5, 30);
	    nameLabel.setForeground(participantColor);
	    this.add(nameLabel,c);
	    
	    this.coinsLabel = new JLabel("");
	    c.weightx = 1;
	    c.ipadx = 20;
	    c.gridx = 1;
	    c.gridy = 0;
	    c.gridwidth = 1;
	    c.gridheight = 1;
	    c.insets = new Insets(10, 30, 5, 30);   
	    coinsLabel.setForeground(participantColor);
	    this.add(coinsLabel,c);
	    
	    this.positionLabel = new JLabel("");
	    c.weightx = 1;
	    c.ipadx = 20;
	    c.gridx = 0;
	    c.gridy = 1;
	    c.gridwidth = 2;
	    c.gridheight = 1;
	    //c.insets = new Insets(30, 50, 10, 50);   
	    this.positionLabel.setForeground(participantColor);
	    this.add(this.positionLabel,c);
	    
	    this.acceptButton = new JButton("Accept");
	    acceptButton.setName(number+"accept");
	    acceptButton.addActionListener(listen);
	    c.weightx = 1;
	    c.ipadx = 20;
	    c.gridx = 0;
	    c.gridy = 2;
	    c.gridwidth = 2;
	    c.gridheight = 1;
	    c.insets = new Insets(50, 5, 20, 5);
	    this.add(this.acceptButton,c);
	    
	    setBackground(Color.white);
	    
	    setBorder(new LineBorder(Color.black,1));
	}
	public void setPositionLabel(String text){
		this.positionLabel.setText(text);
	}
	
	public void setCoinsLabel(int coinsNumber){
		this.coinsLabel.setText("Pieces : "+coinsNumber);
	}
	    
	public void activate(){
		this.acceptButton.setEnabled(true);
	}
	
	public void inactivate(){
		this.acceptButton.setEnabled(false);
	}
}
