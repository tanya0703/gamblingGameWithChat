package negotiation.client.view;


import java.awt.GridLayout;
import java.awt.Image;

import javax.swing.JPanel;

import negotiation.data.AuctionData;



public class CardsPanel extends JPanel implements AuctionData{	
	
	
	
	private Image [] images=new Image [9];
	
	private ImageCanvas [] imagesCanvas=new ImageCanvas [9];
	
	private static final long serialVersionUID = 1L;	
	
	public CardsPanel() {
		
		this.setLayout(new GridLayout(1,9));
		
		for(int i=0;i<cardsNames.length;i++){
			images[i]= getToolkit().getImage(picturesDir+"/"+cardsNames[i]+picturesExtention);
			imagesCanvas[i]= new ImageCanvas(images[i]);
		}
		
		for(int i=0;i<cardsNames.length;i++){
			this.add(this.imagesCanvas[i]);
		}
		
	   this.setSize(getLayout().preferredLayoutSize(this));
	}

	public void refresh(int [] cards){
		int k=0;
		
		for(int i=0;i<cards.length;i++){
			for(int j=0;j<cards[i];j++){
				imagesCanvas[k].setImage(this.images[i]);
				imagesCanvas[k].repaint();
				k++;
			}
		}
		while(k<imagesCanvas.length){
			imagesCanvas[k].setImage(null);
			imagesCanvas[k].repaint();
			k++;
		}
	}
}
