package negotiation.client.view;

import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.Image;

public class ImageCanvas extends Canvas {

	private static final long serialVersionUID = 1L;

	Image image;

	public ImageCanvas(Image image) {
		setSize(100, 150);
		this.image=image;
	}
	
	public ImageCanvas(Image image, int width, int height) {
		setSize(width, height);
		this.image=image;
	}

	public void setImage(Image image) {
		this.image = image;
	}

	public void paint(Graphics g) {
		g.drawImage(image, 0, 0, this);
	}
}
