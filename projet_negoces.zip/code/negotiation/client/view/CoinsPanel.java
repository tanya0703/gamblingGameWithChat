package negotiation.client.view;


import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

import negotiation.data.AuctionData;



public class CoinsPanel extends JPanel implements AuctionData{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ImageCanvas image;
	private JLabel labelCoinsNb;	
	
	public CoinsPanel(){	
		this.setLayout(new GridLayout(2,1));		
		this.image = new ImageCanvas(getToolkit().getImage(picturesDir+"/coins"+picturesExtention),60,60);
		this.labelCoinsNb=new JLabel("Pieces : 0");
		this.add(this.image);
		this.add(this.labelCoinsNb);
	}
	
	public CoinsPanel(int nbCoins){	
		this.setLayout(new GridLayout(2,1));
		this.image = new ImageCanvas(getToolkit().getImage(picturesDir+"/coins"+picturesExtention),60,60);
		this.labelCoinsNb=new JLabel();
		this.add(this.image);
		this.add(this.labelCoinsNb);
		this.labelCoinsNb.setText("Pieces : "+nbCoins);
	}

	public void refresh(int nbCoins){
		this.labelCoinsNb.setText("Pieces : "+nbCoins);
	}
}
