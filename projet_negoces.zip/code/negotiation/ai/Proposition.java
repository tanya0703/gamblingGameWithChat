package negotiation.ai;

public class Proposition {
  private int card;
  private int coins;

  public Proposition(int card, int coins) {
    this.card = card;
    this.coins = coins;
  }

  public int getCard() {
    return card;
  }

  public int getCoins() {
    return coins;
  }
}
