package negotiation.ai;

public enum PersonalityType { NORMAL, CAREFUL, AMBITIOUS }
