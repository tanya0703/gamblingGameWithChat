package negotiation.ai;

public class NoCorrespondingPersonalityException extends Exception {
  public NoCorrespondingPersonalityException(String message) {
      super(message);
  }
}
