package negotiation.ai;

import java.rmi.*;
import java.util.*;
import java.util.Map.*;
import negotiation.server.controller.*;
import negotiation.data.*;

public class Strategy implements AuctionData {
  private Personality personality;
  private Knowledge knowledge;
  private int state;
  private NegotiationControllerIf controller;

  public Strategy(Personality personality, Knowledge knowledge, int state, NegotiationControllerIf controller) {
    this.personality = personality;
    this.knowledge = knowledge;
    this.state = state;
    this.controller = controller;
  }

  public Action doAction() throws RemoteException {
    Action action = new Action("NOACTION");
    boolean aSeller = false;

    if(state==BUYER) {
      String aiSituation = this.controller.getParticipantSituation(knowledge.getAiPlayer());

      if(aiSituation.contains("acheteur") || aiSituation.contains("vendeur")) {
        if(knowledge.lastPropositionExists() && !knowledge.sameCards()) {
          knowledge.updateVendorCards();
        }
      }

      for (int id : knowledge.getPlayersId()){
        if(controller.getState(id) == SELLER) {
          String sellerSituation = this.controller.getParticipantSituation(id);
          if(!sellerSituation.contains("vendeur") && (sellerSituation.contains("vend"))) {

            //Set diamond possessor
            if(knowledge.isFirstTurn())
              knowledge.defineDiamondPossessor(id);

            int cardSold = Arrays.asList(nomsCartes).indexOf(sellerSituation.split(" ")[2]);

            if(aiSituation.contains("propose") && aiSituation.contains("une carte")) {
              int cardProposed = Arrays.asList(nomsCartes).indexOf(aiSituation.split(" ")[4]);
              knowledge.defineLastCards();
              knowledge.defineLastProposition(id, cardSold, cardProposed);
            }
            else if(aiSituation.contains("propose")) {
              knowledge.defineLastCards();
              knowledge.defineLastProposition(id, cardSold, -1);
            }

            if(knowledge.isFirstCard(id, cardSold))
              knowledge.defineFirstCard(id, cardSold);

            knowledge.addCardSoldOrBidByOpponents(id, cardSold);

            if(!knowledge.aiHasCard(cardSold)) {
              try {
                Proposition bestProposition = makeABid();
                action = new Action("BIDUP", knowledge.getAiPlayer(), bestProposition);
              }
              catch(NoGoodPropositionException e) {
                action = new Action("NOACTION");
              }
            }
            else {
              action = new Action("TAKEOUT", knowledge.getAiPlayer());
            }
          }
          aSeller = true;
        }
      }
      if(!aSeller) {
        action = new Action("TAKEOUT", knowledge.getAiPlayer());
      }
    }
    else if(state==SELLER) {
      String aiSituation = this.controller.getParticipantSituation(knowledge.getAiPlayer());
      if(aiSituation.contains("vendeur")) {
        if(knowledge.lastPropositionExists() && !knowledge.sameCards()) {
          knowledge.updateVendorCards();
        }
        action = new Action("AUCTIONACARD", knowledge.getAiPlayer(), knowledge.cardToSell(knowledge.getAiPlayer()));
      }
      else if(aiSituation.contains("vend")) {
        try {
          int bestBid = acceptABid();
          action = new Action("ACCEPTBID", knowledge.getAiPlayer(), bestBid);
        }
        catch(NoGoodPropositionException e) {
          action = new Action("NOACTION");
        }
      }
    }

    return action;
  }

  public Knowledge getNewKnowledge() {
    return knowledge;
  }

  public Proposition makeABid() throws RemoteException, NoGoodPropositionException {
    ArrayList<Proposition> propositions = listPropositions();
    return bestProposition(propositions);
  }

  public int acceptABid() throws RemoteException, NoGoodPropositionException {
    String aiSituation = this.controller.getParticipantSituation(this.knowledge.getAiPlayer());
    int cardSold = Arrays.asList(nomsCartes).indexOf(aiSituation.split(" ")[2]);
    HashMap<Integer,Proposition> bids = listBids();
    HashMap<Integer, Double> dico = new HashMap<Integer, Double>();
    int bestBid = -1;

    for(Entry<Integer, Proposition> entry : bids.entrySet()) {
        int participant = entry.getKey();
        Proposition proposition = entry.getValue();

        if(proposition.getCard()!=-1) {
          if(knowledge.isFirstCard(participant, proposition.getCard()))
            knowledge.defineFirstCard(participant, proposition.getCard());

          knowledge.addCardSoldOrBidByOpponents(participant, proposition.getCard());
        }

        dico.put(participant, selfSatisfaction(proposition)/participantSatisfaction(participant, cardSold));
    }

    try {
      bestBid = bestBidByRatio(dico);
      if(bids.get(bestBid).getCard()!=-1) {
        knowledge.addCardReceivedByOpponents(bestBid, bids.get(bestBid).getCard());
        knowledge.addCardsToPlayer(bids.get(bestBid).getCard(), -1, bestBid);
      }
    }
    catch (NoGoodPropositionException e) {
      throw new NoGoodPropositionException(e.getMessage());
    }

    return bestBid;
  }

  private HashMap<Integer,Proposition> listBids() throws RemoteException {
    Integer[] ids = knowledge.getPlayersId();
    HashMap<Integer,Proposition> bids = new HashMap<Integer, Proposition>();

    for (int player : ids) {
      String playerSituation = this.controller.getParticipantSituation(player);
      if(playerSituation.contains("propose")) {
        if(playerSituation.contains("carte") && playerSituation.contains("pieces")) {
          bids.put(player, new Proposition(Arrays.asList(nomsCartes).indexOf(playerSituation.split(" ")[4]), Integer.parseInt(playerSituation.split(" ")[6])));
        }
        else if(playerSituation.contains("carte")) {
          bids.put(player, new Proposition(Arrays.asList(nomsCartes).indexOf(playerSituation.split(" ")[4]), 0));
        }
        else if(playerSituation.contains("pieces")) {
          bids.put(player, new Proposition(-1, Integer.parseInt(playerSituation.split(" ")[2])));
        }
      }
    }
    return bids;
  }

  private ArrayList<Proposition> listPropositions() throws RemoteException {
    Integer[] cards = knowledge.aiCards().getCardsInHand();
    int coins = knowledge.aiCoins();

    ArrayList<Proposition> propositions = new ArrayList<Proposition>();

    for(int coin=1; coin<=coins; coin++) {
        Proposition p = new Proposition(-1, coin);
        propositions.add(p);
    }

    for(int card : cards) {
      for(int coin=0; coin<=coins; coin++) {
          Proposition p = new Proposition(card, coin);
          propositions.add(p);
      }
    }
    return propositions;
  }

  private Proposition bestProposition(ArrayList<Proposition> propositions) throws RemoteException, NoGoodPropositionException {
    HashMap<Proposition, Double> dico = new HashMap<Proposition, Double>();
    HashMap<Integer,Proposition> bids = listBids();
    bids.remove(knowledge.getAiPlayer());
    double vendorSatisfactionWithBestBid = 0;

    for(Entry<Integer, Proposition> entry : bids.entrySet()) {
      int participant = entry.getKey();
      Proposition bid = entry.getValue();

      if(bid.getCard()!=-1) {
        if(knowledge.isFirstCard(participant, bid.getCard()))
          knowledge.defineFirstCard(participant, bid.getCard());

        knowledge.addCardSoldOrBidByOpponents(participant, bid.getCard());
      }

      double vendorSatisfactionWithBid = vendorSatisfaction(bid);
      if(vendorSatisfactionWithBid>vendorSatisfactionWithBestBid)
        vendorSatisfactionWithBestBid = vendorSatisfactionWithBid;
    }

    for (Proposition p : propositions) {
      double vendorSatisfactionWithProposition = vendorSatisfaction(p);
      double ratio = selfSatisfaction(p)/vendorSatisfactionWithProposition;
      if(vendorSatisfactionWithBestBid!=0) {
        if(vendorSatisfactionWithProposition>vendorSatisfactionWithBestBid)
          dico.put(p, ratio);
      }
      else
        dico.put(p, ratio);
    }

    return bestPropositionByRatio(dico);
  }


  private Proposition bestPropositionByRatio(HashMap<Proposition, Double> dico) throws RemoteException, NoGoodPropositionException{
    Proposition bestProp = null;
    Double bestSat = 0.0;

    for(Entry<Proposition, Double> entry : dico.entrySet()) {
        Proposition prop = entry.getKey();
        Double sat = entry.getValue();
        if(sat>bestSat) {
          bestSat = sat;
          bestProp = prop;
        }
    }

    if(bestProp==null)
      throw new NoGoodPropositionException("No good proposition for agent.");

    return bestProp;
  }

  private int bestBidByRatio(HashMap<Integer, Double> dico) throws RemoteException, NoGoodPropositionException{
    int bestBid = -1;
    Double bestSat = 0.0 ;

    for(Entry<Integer, Double> entry : dico.entrySet()) {
        int bid = entry.getKey();
        Double sat = entry.getValue();
        if(sat>bestSat) {
          bestSat = sat;
          bestBid = bid;
        }
    }

    if(bestBid==-1)
      throw new NoGoodPropositionException("No good bid for agent.");

    return bestBid;
  }

  private Double selfSatisfaction(Proposition p) throws RemoteException{
    Double selfSatisfaction = 0.0;
    int card = p.getCard();
    int coins = p.getCoins();

    if(state==SELLER) {
      if(card!=-1) {
        if(knowledge.aiCards().isCompleteIf(card)) {
          return 100.0;
        }
        else if (!knowledge.aiHasCard(card)) {
            selfSatisfaction = 90.0;
        }
      }
      else {
        if(personality.getType()==PersonalityType.NORMAL)
          selfSatisfaction = -30.0;
        else if(personality.getType()==PersonalityType.CAREFUL)
          selfSatisfaction = -15.0;
        else if(personality.getType()==PersonalityType.AMBITIOUS)
          selfSatisfaction = -50.0;
      }
      selfSatisfaction = selfSatisfaction + 5*coins;
    }
    else if(state==BUYER) {
      if(card!=-1) {
        if(knowledge.aiCards().getNb(card)>1) {
          if(personality.getType()==PersonalityType.NORMAL)
            selfSatisfaction = 50.0;
          else if(personality.getType()==PersonalityType.CAREFUL)
            selfSatisfaction = 25.0;
          else if(personality.getType()==PersonalityType.AMBITIOUS)
            selfSatisfaction = 100.0;
        }
      }
      else {
        if(personality.getType()==PersonalityType.NORMAL)
          selfSatisfaction = 40.0;
        else if(personality.getType()==PersonalityType.CAREFUL)
          selfSatisfaction = 20.0;
        else if(personality.getType()==PersonalityType.AMBITIOUS)
          selfSatisfaction = 50.0;
      }
      selfSatisfaction = selfSatisfaction - 5*coins;
    }
    return selfSatisfaction;
  }

  private Double vendorSatisfaction(Proposition p) throws RemoteException {
    Double vendorSatisfaction = 1.0;
    int card = p.getCard();
    int coins = p.getCoins();

    for (int id : knowledge.getPlayersId()){
      if(controller.getState(id) == SELLER) {
        if(card!=-1) {
          if(knowledge.playerCards(id).isCompleteIf(card)) {
            return 100.0;
          }
          else if (!knowledge.playerHasCard(id, card)) {
            vendorSatisfaction = 50.0;
          }
        }
        vendorSatisfaction = vendorSatisfaction + 5*coins;
      }
    }
    return vendorSatisfaction;
  }

  private Double participantSatisfaction(int participant, int cardSold) throws RemoteException {
    Double participantSatisfaction = 1.0;

    if(knowledge.playerCards(participant).isCompleteIf(cardSold)) {
      return 100.0;
    }
    else if (!knowledge.playerHasCard(participant, cardSold)) {
      participantSatisfaction = 50.0;
    }

    return participantSatisfaction;
  }

}
