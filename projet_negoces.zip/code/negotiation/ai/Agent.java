package negotiation.ai;

import negotiation.server.controller.*;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.*;
import java.util.*;
import negotiation.data.*;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.*;

public class Agent extends UnicastRemoteObject implements NegotiationView, AuctionData  {
  private Knowledge knowledge;
  private int state;
  private Strategy strategy;
  private int[] othersNumbers;
  private NegotiationControllerIf controller;
  private Personality personality;
  public static boolean running;
  private Runnable taskAction = new Runnable() {
            public void run() {
              if(!running) {
                Agent.running = true;
                //this.controller.getParticipantSituation(this.participantNumber);
                // apres maj des données on appele la methode doAction de strategy
                try {
                  Strategy strategy = new Strategy(personality, knowledge, state, controller);
                  Action action = strategy.doAction();

                  knowledge = strategy.getNewKnowledge();

                  System.out.println(action.getOrder());

                  if(state!=OUT_OF_AUCTION) {
                    switch (action.getOrder()) {
                      case "NOACTION":  System.out.println("No action");
                            break;

                      case "BIDUP": controller.bidUp(action.getAi(), action.getProposition().getCard(), action.getProposition().getCoins());
                            break;

                      case "AUCTIONACARD":  controller.auctionAcard(action.getAi(), action.getBuyerOrCardSold());
                            break;

                      case "TAKEOUT":  controller.takeOut(action.getAi());
                            break;

                      case "ACCEPTBID":  controller.acceptBid(action.getAi(), action.getBuyerOrCardSold());
                            break;

                      default :  System.out.println("Action not defined.");
                                 break;
                    }
                  }

                  System.out.println("Action performed");
                }
                catch (RemoteException e) {
                  e.printStackTrace();
                }
                Agent.running = false;
              }
            }
          };

  public Agent(Personality personality) throws RemoteException, NoCorrespondingPersonalityException{
    this.personality = personality;
    this.running = false;
	}

  //on ajoute un main qui se connecte au controlleur

  public void init(int[] othersNumbers, int participantNumber, NegotiationControllerIf controller) throws RemoteException{
    // on initialise le knowledge
    this.controller = controller;
    int[] aiCards = this.controller.getCards(participantNumber);
    int aiPlayer = participantNumber;

    this.knowledge = new Knowledge(aiPlayer, aiCards, othersNumbers);

    this.othersNumbers = othersNumbers;
    System.out.println("agent initialise");

  }

  public void refresh() throws RemoteException {
    System.out.println("refresh");
    // met a jour l'etat du joueur courant
    this.state=controller.getState(this.knowledge.getAiPlayer());
    this.knowledge.setCards(controller.getCards(this.knowledge.getAiPlayer()), this.knowledge.getAiPlayer());
    this.knowledge.setCoins(controller.getCoinsNumber(this.knowledge.getAiPlayer()), this.knowledge.getAiPlayer());

    System.out.println("Etat du jeu mis a jour");

    showAiHand();
    for(int id : this.othersNumbers) {
      showPlayerHand(id, controller.getName(id));
    }

    ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
    int delay = 2;
    scheduler.schedule(this.taskAction, delay, TimeUnit.SECONDS);
    scheduler.shutdown();
  }

  private void showAiHand() {
		System.out.println("====================== Agent Hand ======================\n");
		System.out.println(knowledge.aiCards().toString());
	}

  private void showPlayerHand(int player, String name) {
		System.out.println("====================== "+name+" Hand known ======================\n");
		System.out.println(knowledge.playerCards(player).toString());
	}

  public void setBuyerView() throws RemoteException{

  }
	public void setSellerView() throws RemoteException{

  }

  public void setOutOfAuctionView() throws RemoteException{

  }
	public void receiveMessage(String hour, String user, String message, int participant) throws RemoteException{

  }

  public Personality getPersonality() {
    return personality;
  }

}
