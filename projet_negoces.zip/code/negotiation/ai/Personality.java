package negotiation.ai;

public class Personality {

  private PersonalityType type;

  public Personality(String type) throws NoCorrespondingPersonalityException {
    switch(type) {
      case "normal": this.type = PersonalityType.NORMAL;
                     break;
      case "careful": this.type = PersonalityType.CAREFUL;
                      break;
      case "ambitious": this.type = PersonalityType.AMBITIOUS;
                        break;
      default:
        throw new NoCorrespondingPersonalityException("Pas de personnalité correspondante.");
    }
  }

  public PersonalityType getType() {
    return type;
  }
}
