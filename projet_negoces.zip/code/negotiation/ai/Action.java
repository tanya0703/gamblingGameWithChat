package negotiation.ai;

public class Action {

  private String order;
  private int ai;
  private Proposition proposition;
  private int buyerOrCardSold;

  public Action(String order, int ai, Proposition proposition) {
    this.order = order;
    this.ai = ai;
    this.proposition = proposition;
  }

  public Action(String order, int ai, int buyerOrCardSold) {
    this.order = order;
    this.ai = ai;
    this.buyerOrCardSold = buyerOrCardSold;
  }

  public Action(String order, int ai) {
    this.order = order;
    this.ai = ai;
  }

  public Action(String order) {
    this.order = order;
  }

  public String getOrder() {
    return order;
  }

  public int getAi() {
    return ai;
  }

  public Proposition getProposition() {
    return proposition;
  }

  public int getBuyerOrCardSold() {
    return buyerOrCardSold;
  }

}
