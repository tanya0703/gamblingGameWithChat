package negotiation.ai;

import negotiation.server.model.Hand;
import java.rmi.*;
import java.util.*;

public class Knowledge {
	private int aiPlayer; // The int who knows this knowledge
	private HashMap<Integer, Hand> cardsAssociations = new HashMap<Integer, Hand>(); // The known hands for each int
	private HashMap<Integer, Integer> coinsAssociations = new HashMap<Integer, Integer>(); // The known coins for each int
	private HashMap<Integer, ArrayList<Integer>> cardsSoldOrBidByOpponents = new HashMap<Integer, ArrayList<Integer>>();
	private HashMap<Integer, ArrayList<Integer>> cardsReceivedByOpponents = new HashMap<Integer, ArrayList<Integer>>();
	private Boolean firstTurn;
	private Integer[] lastCards = null;
	private int[] lastProposition = null;

	public Knowledge(int aiPlayer, int[] aiCards, int[] opponents) {
		this.firstTurn = true;
		this.aiPlayer = aiPlayer;
		cardsAssociations.put(aiPlayer, new Hand(aiCards));
		coinsAssociations.put(aiPlayer, 15);

		for(int op : opponents) {
			coinsAssociations.put(op, 15); // Each int begins with 15 coins
			cardsAssociations.put(op, new Hand(0, 0, 0, 0, 0, 0, 0, 0)); // We don't know shit
			cardsSoldOrBidByOpponents.put(op, new ArrayList<Integer>());
			cardsReceivedByOpponents.put(op, new ArrayList<Integer>());
		}
	}

	public void setCards(int[] cards, int player) {
		cardsAssociations.put(player, new Hand(cards));
	}

	public void setCoins(int coins, int player) {
		coinsAssociations.put(player, coins);
	}

	public void addCardSoldOrBidByOpponents(int opponent, int card) {
		if(!this.cardsSoldOrBidByOpponents.get(opponent).contains(card))
			this.cardsSoldOrBidByOpponents.get(opponent).add(card);
	}

	public void addCardReceivedByOpponents(int opponent, int card) {
		if(!this.cardsReceivedByOpponents.get(opponent).contains(card)) {
			this.cardsReceivedByOpponents.get(opponent).add(card);
			this.cardsAssociations.get(opponent).giveCards(card, 1);
		}
	}

	public boolean isFirstTurn() {
		return firstTurn;
	}

	public void defineDiamondPossessor(int player) {
		this.firstTurn = false;
		this.cardsAssociations.get(player).giveCards(0, 1);
	}

	public void defineLastCards() {
		this.lastCards = aiCards().getCardsInHand();
	}

	public void defineLastProposition(int vendor, int cardSold, int cardProposed) {
		this.lastProposition = new int[]{vendor, cardSold, cardProposed};
	}

	public Boolean lastPropositionExists() {
		return (lastProposition!=null);
	}

	public Boolean sameCards() {
		return (this.lastCards==this.cardsAssociations.get(aiPlayer).getCardsInHand());
	}

	public void updateVendorCards() {
		this.cardsAssociations.get(this.lastProposition[0]).giveCards(this.lastProposition[1], -1);
		if(lastProposition[2]!=-1)
			this.cardsAssociations.get(this.lastProposition[0]).giveCards(this.lastProposition[2], 1);

		this.lastProposition = null;
	}

	public boolean isFirstCard(int opponent, int card) {
		if(card!=0 && !this.cardsSoldOrBidByOpponents.get(opponent).contains(card) && !this.cardsReceivedByOpponents.get(opponent).contains(card))
			return true;
		else
			return false;
	}

	public void defineFirstCard(int opponent, int card) {
		cardsAssociations.get(opponent).setNb(card, 4);
	}

	public void addCardsToPlayer(int card, int count, int player) {
		cardsAssociations.get(player).giveCards(card, count);
	}

	public void addCoinsToPlayer(int count, int player) {
		coinsAssociations.put(player, coinsAssociations.get(player) + count);
	}

	public int getAiPlayer() {
		return aiPlayer;
	}

	public int aiCoins() {
		return coinsAssociations.get(aiPlayer);
	}

	public Hand aiCards() {
		return cardsAssociations.get(aiPlayer);
	}

	public Hand playerCards(int player) {
		return cardsAssociations.get(player);
	}

	public boolean aiHasCard(int card) {
		return cardsAssociations.get(aiPlayer).hasCard(card);
	}

	public boolean playerHasCard(int player, int card) {
		return cardsAssociations.get(player).hasCard(card);
	}

	public int countPlayerCard(int player, int card) {
		return cardsAssociations.get(player).getNb(card);
	}

	public int cardToSell(int player) {
		Hand hand = cardsAssociations.get(player);
		return hand.getCardMostPresent();
	}

	public Integer[] getPlayersId() {
		Set<Integer> keySet = cardsAssociations.keySet();
    List<Integer> keyList = new ArrayList<Integer>(keySet);

		Integer[] stockArr = new Integer[keyList.size()];
		stockArr = keyList.toArray(stockArr);

		return stockArr;
	}

}
