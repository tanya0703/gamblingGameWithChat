package negotiation.ai;

public class NoGoodPropositionException extends Exception {
    public NoGoodPropositionException(String message) {
        super(message);
    }
}
