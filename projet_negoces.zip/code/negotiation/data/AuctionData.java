package negotiation.data;

public interface AuctionData {
	public static final int DIAMOND=0;
	public static final int BOOK=1;
	public static final int CIGAR=2;
	public static final int COFFEE=3;
	public static final int HONEY=4;
	public static final int JEWEL=5;
	public static final int SPICE=6;
	public static final int TEA=7;
	public static final int WINE=8;

	public final static int BUYER = 0;
	public final static int SELLER = 1;
	public final static int OUT_OF_AUCTION = 2;

	static final String[] cardsNames={"diamond","book","cigar","coffee","honey","jewell","spice","tea","wine"};
	static final String[] nomsCartes={"diamant","livre","cigare","cafe","miel","bijoux","epices","the","vin"};	
	/** pictures directory */
	static final String picturesDir="pictures";
	static final String picturesExtention=".jpg";
}
