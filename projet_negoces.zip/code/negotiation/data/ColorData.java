package negotiation.data;

import java.awt.Color;

public interface ColorData {
	
	/** 4 colors used to diferenciate the 4 participants in the chat and in the panels of the interface : blue, green, purple and orange */
	public static final Color [] participantsColors=new Color []{new Color(0, 102, 204), new Color(51, 153, 102), new Color(153, 000, 255), new Color(255, 51, 0)};

	/** 4 colors used to diferenciate the 4 participants in the chat and in the panels of the interface : blue, green, purple and orange */
	public static final String [] htmlColors=new String []{"0066CC", "339966", "9900FF", "FF3300"};
}
